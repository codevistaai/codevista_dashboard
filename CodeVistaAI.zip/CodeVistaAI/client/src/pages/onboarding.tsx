import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Sparkles, Building, User, Palette } from "lucide-react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Template } from "@shared/schema";

export default function Onboarding() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState<'business' | 'templates'>('business');
  const [businessData, setBusinessData] = useState({
    name: '',
    description: '',
    industry: ''
  });
  const [recommendations, setRecommendations] = useState<Template[]>([]);

  const { data: templates } = useQuery<Template[]>({
    queryKey: ['/api/templates'],
  });

  const generateRecommendations = useMutation({
    mutationFn: async (data: typeof businessData) => {
      // For MVP, we'll do simple keyword matching
      // In production, this would use AI to analyze business context
      const allTemplates = templates || [];
      
      const industryMap: Record<string, string[]> = {
        'business': ['business', 'corporate', 'consulting'],
        'portfolio': ['portfolio', 'creative', 'personal'],
        'ecommerce': ['ecommerce', 'shop', 'store'],
        'tech': ['business', 'portfolio'],
        'creative': ['portfolio', 'creative'],
        'consulting': ['business', 'consulting']
      };

      const industry = data.industry.toLowerCase();
      const matchingCategories = Object.entries(industryMap)
        .filter(([_, keywords]) => keywords.some(keyword => 
          industry.includes(keyword) || data.description.toLowerCase().includes(keyword)
        ))
        .map(([category]) => category);

      const recommended = allTemplates.filter(template => 
        matchingCategories.includes(template.category) ||
        template.category === 'business' // Default fallback
      ).slice(0, 6);

      return recommended;
    },
    onSuccess: (recommended) => {
      setRecommendations(recommended);
      setStep('templates');
      toast({
        title: "Templates Ready!",
        description: `Found ${recommended.length} templates perfect for your business.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate recommendations. Please try again.",
        variant: "destructive",
      });
    }
  });

  const createProject = useMutation({
    mutationFn: async (templateId: string) => {
      const template = templates?.find(t => t.id === templateId);
      if (!template) throw new Error('Template not found');

      const response = await apiRequest('POST', '/api/projects', {
        name: `${businessData.name} Website`,
        templateId: templateId,
        sections: template.sections,
        settings: {
          businessName: businessData.name,
          businessDescription: businessData.description,
          industry: businessData.industry,
          colors: { primary: '#2563eb', secondary: '#64748b' },
          fonts: { heading: 'Inter', body: 'Inter' }
        }
      });
      return await response.json();
    },
    onSuccess: (project: any) => {
      toast({
        title: "Project Created!",
        description: "Your website project is ready for editing.",
      });
      setLocation(`/builder?project=${project.id}`);
    },
    onError: () => {
      toast({
        title: "Error", 
        description: "Failed to create project. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleBusinessSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessData.name || !businessData.description) {
      toast({
        title: "Missing Information",
        description: "Please fill in your business name and description.",
        variant: "destructive",
      });
      return;
    }
    generateRecommendations.mutate(businessData);
  };

  const handleTemplateSelect = (templateId: string) => {
    createProject.mutate(templateId);
  };

  if (step === 'business') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-2xl mx-auto">
            {/* Header */}
            <div className="text-center mb-8">
              <div className="h-16 w-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Building className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold mb-2">Tell Us About Your Business</h1>
              <p className="text-muted-foreground">
                Help us recommend the perfect templates and generate relevant content for your website.
              </p>
            </div>

            {/* Form */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  Business Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBusinessSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="business-name" className="text-base font-medium">
                      Business Name *
                    </Label>
                    <Input
                      id="business-name"
                      placeholder="e.g., Acme Consulting"
                      value={businessData.name}
                      onChange={(e) => setBusinessData(prev => ({ ...prev, name: e.target.value }))}
                      className="mt-2"
                      data-testid="input-business-name"
                    />
                  </div>

                  <div>
                    <Label htmlFor="business-description" className="text-base font-medium">
                      Business Description *
                    </Label>
                    <Textarea
                      id="business-description"
                      placeholder="Describe what your business does, your target audience, and your goals..."
                      value={businessData.description}
                      onChange={(e) => setBusinessData(prev => ({ ...prev, description: e.target.value }))}
                      className="mt-2 min-h-24"
                      data-testid="input-business-description"
                    />
                  </div>

                  <div>
                    <Label htmlFor="industry" className="text-base font-medium">
                      Industry/Category
                    </Label>
                    <Input
                      id="industry"
                      placeholder="e.g., Technology, Consulting, E-commerce, Creative Services"
                      value={businessData.industry}
                      onChange={(e) => setBusinessData(prev => ({ ...prev, industry: e.target.value }))}
                      className="mt-2"
                      data-testid="input-industry"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    size="lg"
                    disabled={generateRecommendations.isPending}
                    data-testid="button-get-templates"
                  >
                    {generateRecommendations.isPending ? (
                      <>Analyzing Your Business...</>
                    ) : (
                      <>
                        Get My Templates
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="h-16 w-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <Palette className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Perfect Templates for {businessData.name}</h1>
            <p className="text-muted-foreground">
              AI-selected templates based on your business description. Click any template to start building.
            </p>
          </div>

          {/* Templates Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.map((template) => (
              <Card 
                key={template.id} 
                className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105"
                onClick={() => handleTemplateSelect(template.id)}
                data-testid={`card-template-${template.id}`}
              >
                <CardContent className="p-0">
                  <div className="aspect-video bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800 relative overflow-hidden">
                    {template.thumbnail ? (
                      <img 
                        src={template.thumbnail} 
                        alt={template.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <User className="h-12 w-12 text-muted-foreground" />
                      </div>
                    )}
                    <div className="absolute top-2 right-2">
                      <Badge variant="secondary" className="capitalize">
                        {template.category}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold mb-1">{template.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      {template.description || `Professional ${template.category} template`}
                    </p>
                    <Button 
                      className="w-full" 
                      disabled={createProject.isPending}
                      data-testid={`button-select-${template.id}`}
                    >
                      {createProject.isPending ? 'Creating...' : 'Start with This Template'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Back Button */}
          <div className="text-center mt-8">
            <Button 
              variant="outline" 
              onClick={() => setStep('business')}
              data-testid="button-back-to-business"
            >
              ← Back to Business Info
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}