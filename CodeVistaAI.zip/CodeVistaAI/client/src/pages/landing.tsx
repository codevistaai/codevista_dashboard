import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Zap, Palette, Download, Sparkles } from "lucide-react";
import { useLocation } from "wouter";

export default function Landing() {
  const [, setLocation] = useLocation();

  const features = [
    {
      icon: <Zap className="h-8 w-8 text-primary" />,
      title: "AI-Powered Content",
      description: "Generate professional content with AI assistance for headlines, descriptions, and more."
    },
    {
      icon: <Palette className="h-8 w-8 text-primary" />,
      title: "Drag & Drop Builder",
      description: "Intuitive visual editor with three-panel Canva-style interface for easy website creation."
    },
    {
      icon: <Download className="h-8 w-8 text-primary" />,
      title: "Export Anywhere",
      description: "Download as HTML, WordPress theme, or React app. Deploy to any platform instantly."
    },
    {
      icon: <Sparkles className="h-8 w-8 text-primary" />,
      title: "Smart Templates",
      description: "Get AI-recommended templates based on your business description and industry."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold">Code Vista AI</span>
          </div>
          <Button 
            onClick={() => setLocation('/auth')}
            className="bg-primary hover:bg-primary/90"
            data-testid="button-login"
          >
            Get Started
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-4 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent mb-6">
            The Canva for Websites
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Create professional websites in minutes with AI-powered design, drag-and-drop editing, and smart content generation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => setLocation('/auth')}
              className="bg-primary hover:bg-primary/90 text-lg px-8 py-6"
              data-testid="button-start-building"
            >
              Start Building Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="text-lg px-8 py-6"
              data-testid="button-watch-demo"
            >
              Watch Demo
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-20">
          {features.map((feature, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="mb-4 flex justify-center">{feature.icon}</div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Screenshots/Preview Section */}
        <div className="mt-20 text-center">
          <h2 className="text-3xl font-bold mb-8">See It In Action</h2>
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl p-4 mx-auto max-w-5xl">
            <div className="aspect-video bg-gradient-to-br from-primary/10 to-blue-500/10 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <div className="h-16 w-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Three-Panel Builder Interface</h3>
                <p className="text-muted-foreground">Template Library • Live Preview • Design Controls</p>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-20 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Ideas?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of creators building beautiful websites with AI assistance. No coding required.
          </p>
          <Button 
            size="lg" 
            onClick={() => setLocation('/auth')}
            className="bg-primary hover:bg-primary/90 text-lg px-12 py-6"
            data-testid="button-get-started-bottom"
          >
            Get Started Free
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm mt-20">
        <div className="container mx-auto px-4 py-8 text-center text-muted-foreground">
          <p>&copy; 2025 Code Vista AI. Built with AI-powered technology.</p>
        </div>
      </footer>
    </div>
  );
}