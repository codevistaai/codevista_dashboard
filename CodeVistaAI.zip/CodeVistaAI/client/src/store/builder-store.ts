import { create } from 'zustand';
import { WebsiteSection, WebsiteSettings, TemplateData, ProjectData, DeviceType, SidebarTab, PropertyTab, PageData } from '@/types/builder';

interface BuilderState {
  // Project data
  currentProject: ProjectData | null;
  currentPage: PageData | null;
  pages: PageData[];
  
  // UI state
  selectedDevice: DeviceType;
  leftSidebarTab: SidebarTab;
  rightSidebarTab: PropertyTab;
  selectedSectionId: string | null;
  zoom: number;
  
  // Modal states
  aiModalOpen: boolean;
  exportModalOpen: boolean;
  
  // Loading states
  isGeneratingContent: boolean;
  isExporting: boolean;
  
  // Actions
  setCurrentProject: (project: ProjectData | null) => void;
  updateProjectSettings: (settings: Partial<WebsiteSettings>) => void;
  updateSection: (sectionId: string, config: Record<string, any>) => void;
  addSection: (section: WebsiteSection) => void;
  removeSection: (sectionId: string) => void;
  duplicateSection: (sectionId: string) => void;
  reorderSections: (sections: WebsiteSection[]) => void;
  
  // Page actions
  setCurrentPage: (page: PageData | null) => void;
  addPage: (page: PageData) => void;
  removePage: (pageId: string) => void;
  updatePage: (pageId: string, updates: Partial<PageData>) => void;
  duplicatePage: (pageId: string) => void;
  
  // UI actions
  setSelectedDevice: (device: DeviceType) => void;
  setLeftSidebarTab: (tab: SidebarTab) => void;
  setRightSidebarTab: (tab: PropertyTab) => void;
  setSelectedSection: (sectionId: string | null) => void;
  setZoom: (zoom: number) => void;
  
  // Modal actions
  openAiModal: () => void;
  closeAiModal: () => void;
  openExportModal: () => void;
  closeExportModal: () => void;
  
  // Loading actions
  setGeneratingContent: (isGenerating: boolean) => void;
  setExporting: (isExporting: boolean) => void;
}

export const useBuilderStore = create<BuilderState>((set, get) => ({
  // Initial state
  currentProject: null,
  currentPage: null,
  pages: [],
  selectedDevice: "desktop",
  leftSidebarTab: "templates",
  rightSidebarTab: "design",
  selectedSectionId: null,
  zoom: 100,
  aiModalOpen: false,
  exportModalOpen: false,
  isGeneratingContent: false,
  isExporting: false,

  // Project actions
  setCurrentProject: (project) => set({ currentProject: project }),
  
  updateProjectSettings: (settings) => set((state) => ({
    currentProject: state.currentProject ? {
      ...state.currentProject,
      settings: { ...state.currentProject.settings, ...settings },
      updatedAt: new Date()
    } : null
  })),
  
  updateSection: (sectionId, config) => set((state) => ({
    currentProject: state.currentProject ? {
      ...state.currentProject,
      sections: state.currentProject.sections.map(section =>
        section.id === sectionId ? { ...section, config: { ...section.config, ...config } } : section
      ),
      updatedAt: new Date()
    } : null
  })),
  
  addSection: (section) => set((state) => ({
    currentProject: state.currentProject ? {
      ...state.currentProject,
      sections: [...state.currentProject.sections, section],
      updatedAt: new Date()
    } : null
  })),
  
  removeSection: (sectionId) => set((state) => ({
    currentProject: state.currentProject ? {
      ...state.currentProject,
      sections: state.currentProject.sections.filter(section => section.id !== sectionId),
      updatedAt: new Date()
    } : null
  })),
  
  duplicateSection: (sectionId) => set((state) => {
    if (!state.currentProject) return {};
    
    const sectionToDuplicate = state.currentProject.sections.find(s => s.id === sectionId);
    if (!sectionToDuplicate) return {};
    
    const newSection: WebsiteSection = {
      ...sectionToDuplicate,
      id: `${sectionToDuplicate.id}-copy-${Date.now()}`,
      order: sectionToDuplicate.order + 1
    };
    
    return {
      currentProject: {
        ...state.currentProject,
        sections: [...state.currentProject.sections, newSection],
        updatedAt: new Date()
      }
    };
  }),
  
  reorderSections: (sections) => set((state) => ({
    currentProject: state.currentProject ? {
      ...state.currentProject,
      sections,
      updatedAt: new Date()
    } : null
  })),

  // UI actions
  setSelectedDevice: (device) => set({ selectedDevice: device }),
  setLeftSidebarTab: (tab) => set({ leftSidebarTab: tab }),
  setRightSidebarTab: (tab) => set({ rightSidebarTab: tab }),
  setSelectedSection: (sectionId) => set({ selectedSectionId: sectionId }),
  setZoom: (zoom) => set({ zoom }),

  // Modal actions
  openAiModal: () => set({ aiModalOpen: true }),
  closeAiModal: () => set({ aiModalOpen: false }),
  openExportModal: () => set({ exportModalOpen: true }),
  closeExportModal: () => set({ exportModalOpen: false }),

  // Loading actions
  setGeneratingContent: (isGenerating) => set({ isGeneratingContent: isGenerating }),
  setExporting: (isExporting) => set({ isExporting: isExporting }),

  // Page management actions
  setCurrentPage: (page) => set({ currentPage: page }),
  
  addPage: (page) => set((state) => ({
    pages: [...state.pages, page],
    currentPage: page
  })),
  
  removePage: (pageId) => set((state) => ({
    pages: state.pages.filter(page => page.id !== pageId),
    currentPage: state.currentPage?.id === pageId ? (state.pages[0] || null) : state.currentPage
  })),
  
  updatePage: (pageId, updates) => set((state) => ({
    pages: state.pages.map(page => 
      page.id === pageId ? { ...page, ...updates } : page
    ),
    currentPage: state.currentPage?.id === pageId 
      ? { ...state.currentPage, ...updates } 
      : state.currentPage
  })),
  
  duplicatePage: (pageId) => set((state) => {
    const pageToDuplicate = state.pages.find(p => p.id === pageId);
    if (!pageToDuplicate) return {};
    
    const newPage: PageData = {
      ...pageToDuplicate,
      id: `${pageToDuplicate.id}-copy-${Date.now()}`,
      name: `${pageToDuplicate.name} Copy`,
      slug: `${pageToDuplicate.slug}-copy`
    };
    
    return {
      pages: [...state.pages, newPage]
    };
  }),
}));
