export interface WebsiteSection {
  id: string;
  type: "header" | "hero" | "about" | "services" | "footer" | "custom";
  config: Record<string, any>;
  order: number;
}

export interface WebsiteSettings {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  typography: {
    fontFamily: string;
    headingSize: number;
    bodySize: number;
  };
  layout: {
    spacing: number;
    containerWidth: string;
  };
  animations: {
    scrollAnimations: boolean;
    hoverEffects: boolean;
    speed: "slow" | "normal" | "fast";
  };
}

export interface TemplateData {
  id: string;
  name: string;
  description: string;
  category: string;
  thumbnail: string;
  sections: WebsiteSection[];
}

export interface PageData {
  id: string;
  name: string;
  slug: string;
  sections: WebsiteSection[];
  isHomePage: boolean;
  seoSettings?: {
    title: string;
    description: string;
    keywords: string[];
  };
}

export interface ProjectData {
  id: string;
  name: string;
  templateId?: string;
  pages: PageData[];
  sections: WebsiteSection[]; // Keep for backward compatibility
  settings: WebsiteSettings;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface AIContentRequest {
  contentType: "headline" | "description" | "services" | "cta";
  businessContext: string;
  tone: "professional" | "friendly" | "creative" | "authoritative";
  additionalContext?: string;
}

export interface AIContentResponse {
  suggestions: string[];
  contentType: string;
}

export interface ComponentData {
  id: string;
  name: string;
  type: string;
  config: Record<string, any>;
}

export type DeviceType = "desktop" | "tablet" | "mobile";
export type SidebarTab = "templates" | "components";
export type PropertyTab = "design" | "content" | "settings";
export type ExportFormat = "static" | "wordpress" | "react";
